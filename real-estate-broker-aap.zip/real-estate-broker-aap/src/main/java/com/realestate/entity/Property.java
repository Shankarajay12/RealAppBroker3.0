package com.realestate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="property")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Property {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="propertyId")
	private int propertyId;
	
	@Column(name="propertyPrice")
	private int propertyPrice;
	
	@Column(name="propertyType")
	private String propertyType;
	
	@Column(name="propertyArea")
	private String propertyArea;
	
	@Column(name="propertyCity")
	private String propertyCity;
	
	@Column(name="propertyState")
	private String propertyState;
	
	@Column(name="path")
	private String path;
}

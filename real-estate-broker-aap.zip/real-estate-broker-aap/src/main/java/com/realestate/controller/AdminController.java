package com.realestate.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdminController {
	

	
	
}

const lbtn = document.getElementById("lbtn");
lbtn.addEventListener('click', () => {
    alert("Please Enter valid Credentials");
});

const fpassword = document.getElementById("fpassword");
fpassword.addEventListener('click', () => {
    alert("Page Not Found");
});